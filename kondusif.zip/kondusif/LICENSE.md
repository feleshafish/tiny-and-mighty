***Note of the author***

this is the first font i made. and what I uploaded here is a demo. For the regular and italic type of this font, I sell it on the creative market